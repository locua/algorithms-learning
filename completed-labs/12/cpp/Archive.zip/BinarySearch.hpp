#include <cstddef>

class BinarySearch {
public:
  bool search(int *, int, size_t, size_t);
  int count(int *, int, size_t, size_t);
};
